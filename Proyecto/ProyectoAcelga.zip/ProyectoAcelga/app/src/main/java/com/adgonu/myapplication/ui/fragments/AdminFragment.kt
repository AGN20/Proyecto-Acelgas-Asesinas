package com.adgonu.myapplication.ui.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.findNavController
import com.adgonu.myapplication.R

class AdminFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_admin, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {

        val botonSet: Button = view.findViewById(R.id.btFJChange)
        val botonCambiar: Button = view.findViewById(R.id.btPasosChange)

        botonSet.setOnClickListener{
            view?.findNavController()?.navigate(R.id.setFragment)
        }

        botonCambiar.setOnClickListener{
            view?.findNavController()?.navigate(R.id.setPasoFragment)
        }

    }

}