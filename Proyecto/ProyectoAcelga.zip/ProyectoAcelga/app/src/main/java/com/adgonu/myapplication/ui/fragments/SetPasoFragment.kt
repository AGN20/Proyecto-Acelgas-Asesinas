package com.adgonu.myapplication.ui.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.adgonu.myapplication.R
import com.google.firebase.firestore.FirebaseFirestore

// TODO: Rename parameter arguments, choose names that match

class SetPasoFragment : Fragment() {

    //Base de datos de Firebase
    val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_set_paso, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {

        val botonSet: Button = view.findViewById(R.id.btSetPasos)
        val botonDelete: Button = view.findViewById(R.id.btDeletePaso)

        val txNombre: TextView = view.findViewById(R.id.edSetPasoNombre)
        val txNombreFJ: TextView = view.findViewById(R.id.edSetPasoNombreFJ)
        val txNumero: TextView = view.findViewById(R.id.edSetPasoNumero)
        val txDescripcion: TextView = view.findViewById(R.id.edmSetPasoDescripcion)

        botonSet.setOnClickListener { setPaso(txNombre, txNombreFJ, txNumero, txDescripcion) }
        botonDelete.setOnClickListener { deletePaso(txNombre, txNombreFJ) }

    }

    private fun setPaso(
        txNombre: TextView,
        txNombreFJ: TextView,
        txNumero: TextView,
        txDescripcion: TextView
    ) {
        val paso = hashMapOf(
            "nombre" to txNombre.text.toString(),
            "nombreFJ" to txNombreFJ.text.toString(),
            "numero" to txNumero.text.toString().toLong(),
            "descripcion" to txDescripcion.text.toString(),
            "completado" to false
        )

        val fj = db.collection("pasos")
            .whereEqualTo("nombre", txNombre.text.toString())
            .whereEqualTo("nombreFJ", txNombreFJ.text.toString())
            .get()
            .addOnSuccessListener { result ->

                if(result.isEmpty){
                    db.collection("pasos").document().set(paso)
                        .addOnSuccessListener { Log.d("TAG", "DocumentSnapshot successfully written!") }
                        .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }
                }else{
                    for(docu in result){
                        db.collection("pasos").document(docu.id).set(paso)
                            .addOnSuccessListener { Log.d("TAG", "DocumentSnapshot successfully written!") }
                            .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }

                    }
                }


            }
            .addOnFailureListener {exception ->
                Log.d("TAG", "error al obtener los datos $exception")
            }


    }

    private fun deletePaso(
        txNombre: TextView,
        txNombreFJ: TextView,
    ) {

        db.collection("pasos")
            .whereEqualTo("nombre", txNombre.text.toString())
            .whereEqualTo("nombreFJ", txNombreFJ.text.toString())
            .get()
            .addOnSuccessListener { result ->
                for(docu in result){
                    db.collection("pasos").document(docu.id).delete()
                        .addOnSuccessListener { Log.d("TAG", "DocumentSnapshot successfully written!") }
                        .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }

                }


            }
            .addOnFailureListener {exception ->
                Log.d("TAG", "error al obtener los datos $exception")
            }


    }
}