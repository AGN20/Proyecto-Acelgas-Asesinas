package com.adgonu.myapplication.ui.fragments

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.findNavController
import com.adgonu.myapplication.R
import com.google.firebase.firestore.FirebaseFirestore

class SetFragment : Fragment() {

    //Base de datos de Firebase
    val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_set, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {

        val botonSet: Button = view.findViewById(R.id.btSetFJ)
        val botonDelete: Button = view.findViewById(R.id.btDeleteFj)

        val txNombre: TextView = view.findViewById(R.id.edNombreSet)
        val txCapital: TextView = view.findViewById(R.id.edCapitalSet)
        val txSocios: TextView = view.findViewById(R.id.edNumSociosSet)
        val txResponsabilidad: TextView = view.findViewById(R.id.edResponSet)

        botonSet.setOnClickListener{ setJf(txNombre, txCapital, txSocios, txResponsabilidad) }
        botonDelete.setOnClickListener{ deletePaso(txNombre, txCapital) }

    }

    private fun setJf(
        txNombre: TextView,
        txCapital: TextView,
        txSocios: TextView,
        txResponsabilidad: TextView
    ) {
        val juridicForm = hashMapOf(
            "nombre" to txNombre.text.toString(),
            "capital" to txCapital.text.toString().toLong(),
            "numSocios" to txSocios.text.toString().toLong(),
            "responsabilidad" to txResponsabilidad.text.toString(),
        )

        val fj = db.collection("formasJuridicas")
            .whereEqualTo("nombre", txNombre.text.toString())
            .get()
            .addOnSuccessListener { result ->

                if(result.isEmpty){
                    db.collection("formasJuridicas").document().set(juridicForm)
                        .addOnSuccessListener { Log.d("TAG", "DocumentSnapshot successfully written!") }
                        .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }
                }else{
                    for(docu in result){

                        db.collection("formasJuridicas").document(docu.id).set(juridicForm)
                            .addOnSuccessListener { Log.d("TAG", "DocumentSnapshot successfully written!") }
                            .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }

                    }
                }


            }
            .addOnFailureListener {exception ->
                Log.d("TAG", "error al obtener los datos $exception")
            }

    }

    private fun deletePaso(
        txNombre: TextView,
        txNombreFJ: TextView,
    ) {

        db.collection("formasJuridicas")
            .whereEqualTo("nombre", txNombre.text.toString())
            .get()
            .addOnSuccessListener { result ->
                for(docu in result){
                    db.collection("formasJuridicas").document(docu.id).delete()
                        .addOnSuccessListener { Log.d("TAG", "DocumentSnapshot successfully written!") }
                        .addOnFailureListener { e -> Log.w("TAG", "Error writing document", e) }

                }


            }
            .addOnFailureListener {exception ->
                Log.d("TAG", "error al obtener los datos $exception")
            }


    }

}