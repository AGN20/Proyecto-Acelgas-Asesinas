package com.adgonu.myapplication.viewmodel

import android.view.View
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.adgonu.myapplication.databinding.ItemDetailsBinding
import com.adgonu.myapplication.model.model.Details

/** Introducimos los datos en el item_details **/
class DetailsViewHolder (view: View): RecyclerView.ViewHolder(view) {
    private val binding = ItemDetailsBinding.bind(view)

    //Ponemos en variables los campos del item_details
    var tvNombre: TextView = binding.tvNombre
    var tvDescripcion: TextView = binding.tvDescripcion
    var cbCompleto: CheckBox = binding.cbCompletado


    fun bind (details: Details) {
        tvNombre.text = details.numero.toString() + ". " + details.nombre
        tvDescripcion.text = details.descripcion
        cbCompleto.isChecked = details.completado
    }

}
