package com.adgonu.myapplication.ui.fragments

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.navigation.findNavController
import com.adgonu.myapplication.R
import com.google.firebase.auth.FirebaseAuth
import java.util.regex.Matcher
import java.util.regex.Pattern

class LoguinFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_loguin, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {
        /** Iniciamos los elementos para poder utilizarlos **/
        val btRegistrar: Button = view.findViewById(R.id.btnRegistrar)
        val btEntrar: Button = view.findViewById(R.id.btnEntrar)
        val edEmail: EditText = view.findViewById(R.id.edtGmail)
        val edPassword: EditText = view.findViewById(R.id.edtContraseña)
        val ivIcono: ImageView = view.findViewById(R.id.imageView)

        ivIcono.setImageResource(R.drawable.icon_login)

        /** REGISTRAR **/
        btRegistrar.setOnClickListener{

            var email = edEmail.text
            var password = edPassword.text

            if (email.isNotEmpty() && password.isNotEmpty()){
                FirebaseAuth.getInstance().createUserWithEmailAndPassword(email.toString(), password.toString()).addOnCompleteListener {
                    if(it.isSuccessful){
                        val bundle = Bundle()
                        bundle.putString("email", email.toString())
                        changeFragment(bundle)
                    }else{

                        if(password.toString().length < 6){ showAlertPassword() }
                        if(!validarEmail(email.toString())){ showAlertEmail() }

                    }
                }
            }else{
                showAlertNotEmty()
            }
        }

        /** ENTRAR **/
        btEntrar.setOnClickListener {

            var email = edEmail.text
            var password = edPassword.text

            if (email.isNotEmpty() && password.isNotEmpty()){
                if(email.toString() == "Administrador" && password.toString() == "Administrador"){
                    changeFragmentAdministrador()
                }else{

                    FirebaseAuth.getInstance().signInWithEmailAndPassword(email.toString(), password.toString()).addOnCompleteListener {
                        if(it.isSuccessful){
                            val bundle = Bundle()
                            bundle.putString("email", email.toString())
                            changeFragment(bundle)
                        }else{ showAlertEntriFailed() }
                    }

                }
            }else{
                showAlertNotEmty()
            }
        }
    }

    /** mensaje FALLO AL AUTENTIFICAR **/
    private fun showAlertEntriFailed(){
        val builder = AlertDialog.Builder(context)
        builder.setTitle("ERROR")
        builder.setMessage("El email o la contraseña son incorrectas")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    /** mensaje FALLO el password no es correcto **/
    private fun showAlertPassword(){
        val builder = AlertDialog.Builder(context)
        builder.setTitle("ERROR")
        builder.setMessage("La contraseña debe tener mas de 6 caracteres")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    /** mensaje FALLO el email no es correcto **/
    private fun showAlertEmail(){
        val builder = AlertDialog.Builder(context)
        builder.setTitle("ERROR")
        builder.setMessage("El email debe parecerse a micorreo@gmail.com")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    /** mensaje FALLO si uno de los elementos esta vacio **/
    private fun showAlertNotEmty(){
        val builder = AlertDialog.Builder(context)
        builder.setTitle("ERROR")
        builder.setMessage("El email o la contraseña esta vacios")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    /** CAMBIAR EL FRAGMENTO **/
    private fun changeFragment(bundle: Bundle){
        view?.findNavController()?.navigate(R.id.formFragment, bundle)
    }

    /** CAMBIAR EL FRAGMENTO ADMINISTRADOR **/
    private fun changeFragmentAdministrador(){
        view?.findNavController()?.navigate(R.id.adminFragment)
    }

    /** VALIDAR EL EMAIL **/
    private fun validarEmail(texto: String): Boolean {
        val patern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
        var comparator: Matcher = patern.matcher(texto)
        return comparator.find()
    }

}