package com.adgonu.myapplication.ui.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.adgonu.myapplication.R
import com.adgonu.myapplication.databinding.FragmentRequestBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RequestFragment : Fragment() {

    val db = FirebaseFirestore.getInstance()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_request, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {

        var txRequest: TextView = view.findViewById(R.id.txRequest)

        var email: String? = null
        var capital: String? = null
        var socios: String? = null

        if (arguments != null){
            email = requireArguments().getString("email")
            capital = requireArguments().getString("capital")
            socios = requireArguments().getString("socios")
        }

        buscarDocumento(txRequest, capital, socios)

    }

    /** Buscamos la forma juridica más adecuada dependiendo de nuestro capital y numero de socios **/
    private fun buscarDocumento(txRequest: TextView ,capital: String?, socios: String?) {
        //Consulta
        val docuFJ = db.collection("formasJuridicas")
            .whereEqualTo("numSocios", socios!!.toInt()) //NumSocios igual a socios indicados
            .whereLessThanOrEqualTo("capital", capital!!.toInt()) //capital menos o igual al capital indicado
            .get()
            .addOnSuccessListener { result -> //Recuperamos el nombre, y lo agregamos al text view
                for (document in result){
                    var docu = document.get("nombre")
                    Log.d("TAG", "Nombre = " + docu)
                    txRequest.text = docu.toString()
                }
            }
            .addOnFailureListener{exception ->
                Log.d("TAG", "error al obtener los datos $exception")
            }

    }

}