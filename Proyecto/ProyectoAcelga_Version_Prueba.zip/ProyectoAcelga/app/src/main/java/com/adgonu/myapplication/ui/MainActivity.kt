package com.adgonu.myapplication.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import com.adgonu.myapplication.R
import com.adgonu.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(){

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ActivityMainBinding.inflate(layoutInflater).also { binding = it }.root)

        // NAVIGATION
        setSupportActionBar(binding.toolbar)

        val navHosFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHosFragment.navController

        val appBarConfiguration = AppBarConfiguration(setOf(
            R.id.options,
            R.id.exit,
        )
        )

        NavigationUI.setupWithNavController(binding.toolbar, navController, appBarConfiguration)

    }

    // NAVIGATION
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId){
            R.id.options -> {
                navController?.navigate(R.id.optionFragment)
                true
            }
            R.id.exit -> {
                navController?.navigate(R.id.loguinFragment)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }

    }

}