package com.adgonu.myapplication.ui.fragments

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import com.adgonu.myapplication.R
import com.google.firebase.firestore.FirebaseFirestore

class FormFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_form, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {
        /** Iniciamos los elementos para poder utilizarlos **/
        val btBuscar: Button = view.findViewById(R.id.btBuscar)
        val edCapital: EditText = view.findViewById(R.id.edtCapital)
        val edSocios: EditText = view.findViewById(R.id.edtSoicos)

        /** REGISTRAR **/
        btBuscar.setOnClickListener{

            var capital = edCapital.text
            var socios = edSocios.text

            if (capital.isNotEmpty() && socios.isNotEmpty()){
                var email: String? = null
                if (arguments != null){
                    email = requireArguments().getString("email")
                }
                val bundle = Bundle()
                bundle.putString("email", email.toString())
                bundle.putString("capital", capital.toString())
                bundle.putString("socios", socios.toString())
                changeFragment(bundle)
            }else{
                showAlertNotEmty()
            }
        }
    }

    /** CAMBIAR EL FRAGMENTO **/
    private fun changeFragment(bundle: Bundle){
        view?.findNavController()?.navigate(R.id.requestFragment, bundle)
    }

    /** mensaje FALLO si uno de los elementos esta vacio **/
    private fun showAlertNotEmty(){
        val builder = AlertDialog.Builder(context)
        builder.setTitle("ERROR")
        builder.setMessage("El capital y los socios no pueden estar vacios")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

}