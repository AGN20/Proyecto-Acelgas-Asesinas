package com.adgonu.myapplication.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.adgonu.myapplication.R
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class RequestFragment : Fragment() {

    val db = Firebase.firestore

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_request, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setup(view)
    }

    private fun setup(view: View) {

        val tvJuridicForms: TextView = view.findViewById(R.id.tvJuridicForm)

        var email: String? = null
        var capital: String? = null
        var socios: String? = null
        if (arguments != null){
            email = requireArguments().getString("email")
            capital = requireArguments().getString("capital")
            socios = requireArguments().getString("socios")
        }
/* //VA MAL NO MUESTRA LO QUE TIENE QUE MOSTRAR
        val jf = db.collection("formasJuridicas")
            .whereLessThanOrEqualTo("capital", capital!!.toInt())
            .whereEqualTo("numSocios", socios!!.toInt())
            .get().result.documents

        tvJuridicForms.text = */
    }

}