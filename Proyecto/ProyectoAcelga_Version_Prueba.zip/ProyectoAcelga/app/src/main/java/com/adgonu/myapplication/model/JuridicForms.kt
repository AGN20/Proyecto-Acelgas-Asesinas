package com.adgonu.myapplication.model

data class JuridicForms(
    val nombre: String,
    val capital: String,
    val numSocios: String,
    val responsabilidad: String,
)
